using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShipScript : MonoBehaviour
{
    int health = 3;
    bool dying = false;
    float deathTimer;
    bool entering;
    float enterTimer;
    bool deathSwitch = false;

    EnemySpawner source;

    private void Update()
    {
        if (dying) {
            if (FindObjectOfType<FauxProjectile>() == null) {
                if (!deathSwitch) {
                    deathSwitch = true;
                    StartCoroutine(Camera.main.GetComponent<CameraController>().Shake(1.375f, .2f));
                }
                transform.Rotate(Vector3.right * 90 / 1.5f * Time.deltaTime);
                if (Time.time >= deathTimer) {
                    source.SpawnEnemy();
                    Camera.main.GetComponent<CameraController>().levelUpTilt();
                    FindObjectOfType<Launcher>().IncreaseRate();
                    AudioBank.current.playRandomVictorySound();
                    PlayerPrefs.SetInt("ShipsSunk", PlayerPrefs.GetInt("ShipsSunk", 0) + 1);
                    Destroy(gameObject);
                }
            } else {
                deathTimer = Time.time + 1.375f;
            }
        }

        if (entering) {
            transform.Translate(Vector2.left * (16 + transform.position.x) / 3f * Time.deltaTime, Space.Self);
            if (Time.time >= enterTimer) {
                entering = false;
                source.ReadyToGo();
            }
        }
    }

    public bool DealDamage() {
        health--;
        dying = health <= 0;
        return dying;
    }

    public void GoForth(EnemySpawner setSource) {
        source = setSource;
        entering = true;
        enterTimer = Time.time + 2f;
    }

    public int GetHealth() { return health; }
}
