using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pointer : MonoBehaviour
{
    SpriteRenderer sr;
    PlayerMovement player;
    CannonScript cannon;

    Vector2 targetPos;

    void Start()
    {
        sr = GetComponentInChildren<SpriteRenderer>();
        player = FindObjectOfType<PlayerMovement>();
        cannon = FindObjectOfType<CannonScript>();
    }

    void Update()
    {
        if (cannon.gamePlaying) {
            if (player.GetCarryingState()) {
                sr.enabled = true;
                targetPos = cannon.transform.position;
            } else if (!cannon.loaded) {
                sr.enabled = true;
                targetPos = FindObjectOfType<CannonBallScript>().transform.position;
            } else { sr.enabled = false; }

            if (sr.enabled) {
                Vector2 dir = targetPos - (Vector2)transform.position;
                float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
                transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

                sr.transform.localPosition = Vector3.right * Mathf.Clamp(Vector2.Distance(targetPos, transform.position) - 1.125f, 0, 4);
            }
        } else {
            sr.enabled = false;
        }
    }
}
