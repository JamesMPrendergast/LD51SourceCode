using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FireTamer : MonoBehaviour
{
    public Transform fire;
    float baseX;
    float maxDistance;
    float fireY;

    void Start()
    {
        baseX = transform.GetChild(0).transform.position.x;
        maxDistance = baseX - fire.position.x;
        fireY = fire.localPosition.y;
    }

    void Update()
    {
        baseX = transform.GetChild(0).transform.position.x;
        float percentFilled = GetComponent<Image>().fillAmount;
        fire.position = new Vector2(baseX - maxDistance * percentFilled, fire.position.y);

        fire.localPosition = new Vector2(fire.localPosition.x, fireY);
    }
}
