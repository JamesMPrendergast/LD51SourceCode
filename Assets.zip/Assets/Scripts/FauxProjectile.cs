using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FauxProjectile : MonoBehaviour
{
    Vector2 velocity;
    Transform target;
    float startingSize;
    float startingDis;
    float timeCreated;

    //physics stuff
    float gravity = 10;
    float time = 1.5f;

    private void Start()
    {

        //shoots at target
        target = FindObjectOfType<EnemyShipScript>().transform;
        float x = (target.localPosition.x - transform.localPosition.x) / time;
        float y = (.5f * gravity * time * time + target.localPosition.y - transform.localPosition.y) / time;
        velocity = new Vector2(x, y);

        //set up
        startingSize = transform.localScale.x;
        startingDis = target.localPosition.x - transform.localPosition.x;
        timeCreated = Time.time;
    }

    void Update()
    {
        transform.Translate(velocity * Time.deltaTime, Space.Self);
        velocity.y -= gravity * Time.deltaTime;

        float size = (target.localPosition.x - transform.localPosition.x) / startingDis * startingSize + (startingSize / 5);
        transform.localScale = Vector3.one * size;

        if (Landed()) {
            ParticleBank.current.playFarExplosion(transform.position);
            StartCoroutine(Camera.main.GetComponent<CameraController>().Shake(.125f, .25f));
            Destroy(gameObject);
        }
    }

    public bool Landed()
    {
        return Vector2.Distance(target.position, transform.position) < 1.5f && Time.time - timeCreated > time / 2;
    }
}
