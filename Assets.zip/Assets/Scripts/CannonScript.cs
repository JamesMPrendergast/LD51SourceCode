using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CannonScript : MonoBehaviour
{
    public GameObject cannonBall, cannonBallProp;
    public List<Vector2> cannonBallPositions = new List<Vector2>();
    public Image ropeTimer;

    public bool loaded;
    float threshold;
    public bool gamePlaying;

    int lastSecond;

    EnemySpawner spawner;

    void Start()
    {
        spawner = FindObjectOfType<EnemySpawner>();
        spawner.SpawnEnemy();
    }

    void Update()
    {
        if (gamePlaying) {
            if (Mathf.FloorToInt(Time.time - (threshold - 10)) != lastSecond) {
                lastSecond = Mathf.FloorToInt(Time.time - (threshold - 10));
                Debug.Log(lastSecond);
            }

            ropeTimer.fillAmount = (threshold - Time.time) / 10;

            if (loaded) {
                gamePlaying = false;
                Fire();
                Debug.Log("success");
                if (!FindObjectOfType<EnemyShipScript>().DealDamage()) {
                    StartRound();
                }
            } else if (Time.time > threshold) {
                gamePlaying = false;
                Camera.main.GetComponent<CameraController>().playerLost = true;
                ParticleBank.current.playEnemyExplosion((Vector3)((Vector2)transform.position + Vector2.one * 2) + Vector3.back);
                StartCoroutine(Camera.main.GetComponent<CameraController>().Shake(3f, 2f));
                Debug.Log("failure");
            }
        }
    }

    void Fire()
    {
        StartCoroutine(Camera.main.GetComponent<CameraController>().Shake(.25f, .5f));

        AudioBank.current.playRandomCannonExplosionSound();
        ParticleBank.current.playMuzzleFlare((Vector3)((Vector2)transform.position + Vector2.one * 2) + Vector3.back);

        GameObject projectile = Instantiate(cannonBallProp, Camera.main.transform);
        projectile.transform.position = (Vector2)transform.position + Vector2.one * 2;
        projectile.transform.position += Vector3.forward * 10;
    }

    public void StartRound()
    {
        threshold = Time.time + 10;
        loaded = false;
        gamePlaying = true;
        SpawnInNewCannonBall();
    }

    void SpawnInNewCannonBall()
    {
        Instantiate(cannonBall, cannonBallPositions[Random.Range(0, cannonBallPositions.Count)], Quaternion.identity);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player")) {
            if (other.GetComponent<PlayerMovement>().GetCarryingState()) {
                AudioBank.current.playRandomPickUpSound();
                other.GetComponent<PlayerMovement>().ChangingCarryingState(false);
                loaded = true;
            }
        }
    }
}
