using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public List<GameObject> enemyTypes = new List<GameObject>();
    CannonScript cannon;

    public void SpawnEnemy() {
        GameObject enemy = Instantiate(enemyTypes[Random.Range(0, enemyTypes.Count)], Camera.main.transform);
        enemy.transform.position = transform.position;
        enemy.transform.localRotation = Quaternion.identity;
        enemy.transform.position = new Vector3(enemy.transform.position.x, enemy.transform.position.y, 5);
        enemy.GetComponent<EnemyShipScript>().GoForth(this);
        if (cannon == null) {
            cannon = FindObjectOfType<CannonScript>();
        }
    }

    public void ReadyToGo() {
        cannon.StartRound();
    }
}
