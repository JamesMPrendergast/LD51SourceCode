using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleBank : MonoBehaviour
{
    public static ParticleBank current;

    public GameObject enemyExplosion, farExplosion, hit, muzzleFlare;

    private void Awake()
    {
        current = this;
    }

    public void playEnemyExplosion(Vector2 pos) {
        GameObject newParticles = Instantiate(enemyExplosion);
        newParticles.transform.position = (Vector3)pos + Vector3.back;
    }
    public void playFarExplosion(Vector2 pos) {
        GameObject newParticles = Instantiate(farExplosion);
        newParticles.transform.position = (Vector3)pos + Vector3.forward;
        newParticles.transform.parent = Camera.main.transform;
    }
    public void playHit(Vector2 pos) {
        GameObject newParticles = Instantiate(hit);
        newParticles.transform.position = (Vector3)pos + Vector3.back;
    }
    public void playMuzzleFlare(Vector2 pos) {
        GameObject newParticles = Instantiate(muzzleFlare);
        newParticles.transform.position = (Vector3)pos + Vector3.forward;
    }
}
