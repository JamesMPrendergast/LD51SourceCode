using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sway : MonoBehaviour
{
    public float offset;
    public float magnitude = 1;
    Vector3 originalPos;

    void Start()
    {
        originalPos = transform.position;
    }

    void Update()
    {
        transform.position = Vector3.Lerp(new Vector3(originalPos.x, originalPos.y - magnitude / 10, originalPos.z),
            new Vector3(originalPos.x, originalPos.y + magnitude / 10, originalPos.z), .5f * Mathf.Sin(Time.time + offset) + .5f);
    }
}
