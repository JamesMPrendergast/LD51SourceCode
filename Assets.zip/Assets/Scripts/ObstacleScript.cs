using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleScript : MonoBehaviour
{
    public float targetY;
    float velocity = -5;
    float impactRadius = 2.5f;
    float impactMagnitude = 15;

    void Update()
    {
        velocity -= 9 * Time.deltaTime;
        transform.Translate(Vector2.up * velocity * Time.deltaTime, Space.World);
        transform.Rotate(Vector3.forward * velocity * 45 * Time.deltaTime);

        if (transform.position.y < targetY) {
            Impact();
        }
    }

    void Impact()
    {
        AudioBank.current.playRandomEnemyExplosionSound();
        ParticleBank.current.playEnemyExplosion(transform.position);

        Collider2D hitCol = Physics2D.OverlapCircle(transform.position, impactRadius, LayerMask.GetMask("Player"));
        if (hitCol != null) {
            AudioBank.current.playRandomHurtSound();
            ParticleBank.current.playHit(hitCol.transform.position);

            Vector2 dir = hitCol.transform.position - transform.position;
            dir = dir.normalized;
            dir = new Vector2(dir.x * 2, Mathf.Abs(dir.y));
            hitCol.GetComponent<Rigidbody2D>().AddForce(dir * impactMagnitude, ForceMode2D.Impulse);
            hitCol.GetComponent<PlayerMovement>().Stun(1.75f);
        }

        StartCoroutine(Camera.main.GetComponent<CameraController>().Shake(.1125f, .5f));
        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) {
            Impact();
        }
    }
}
