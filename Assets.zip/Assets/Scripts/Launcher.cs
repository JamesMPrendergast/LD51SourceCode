using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Launcher : MonoBehaviour
{
    public GameObject enemyProjectile;
    public List<GameObject> targetPositions = new List<GameObject>();

    float warningTime = 3;
    float fireRate = 5;
    float threshold;
    bool blinkingStarted;
    GameObject currentObjective;

    void Start()
    {
        ResetTimer();
        foreach(GameObject targetPosition in targetPositions) {
            ToggleVisibility(targetPosition, true);
        }
    }

    void Update()
    {
        if (Time.time > threshold - warningTime && !blinkingStarted) {
            StartCoroutine(BlinkWarning(currentObjective, warningTime, 4));
            blinkingStarted = true;
        }

        if (Time.time > threshold) {
            GameObject newProjectile = Instantiate(enemyProjectile);
            newProjectile.transform.position = (Vector2)currentObjective.transform.position + Vector2.up * 32.5f;
            newProjectile.GetComponent<ObstacleScript>().targetY = currentObjective.transform.position.y;
            ResetTimer();
        }
    }

    public void ResetTimer()
    {
        threshold = Time.time + 50 / fireRate;
        blinkingStarted = false;
        currentObjective = targetPositions[Random.Range(0, targetPositions.Count)];
    }

    public void IncreaseRate()
    {
        fireRate++;
    }

    IEnumerator BlinkWarning(GameObject warning, float maxTime, float numBlinks)
    {
        float timeElapsed = 0;
        float interval = 0;

        while(timeElapsed < maxTime) {
            timeElapsed += Time.deltaTime;
            interval += Time.deltaTime;

            if (interval > maxTime / (numBlinks * 2 - 1)) {
                interval = 0;
                if (ToggleVisibility(warning)) {
                    AudioBank.current.playRandomWarningSound();
                }
            }

            yield return null;
        }
        ToggleVisibility(warning, true);
    }

    bool ToggleVisibility(GameObject warning, bool hideAll = false)
    {
        Renderer[] sprites = warning.GetComponentsInChildren<Renderer>();
        foreach (Renderer sprite in sprites) {
            if (hideAll) {
                sprite.enabled = false;
            } else {
                sprite.enabled = !sprite.enabled;
            }
        }
        return sprites[0].enabled;
    }
}
