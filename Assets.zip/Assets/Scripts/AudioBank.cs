using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioBank : MonoBehaviour
{
    public static AudioBank current;

    public GameObject soundDummyPrefab;

    public List<AudioClip> cannonExplosionSounds = new List<AudioClip>();
    public List<AudioClip> enemyExplosionSounds = new List<AudioClip>();
    public List<AudioClip> warningSounds = new List<AudioClip>();
    public List<AudioClip> jumpSounds = new List<AudioClip>();
    public List<AudioClip> hurtSounds = new List<AudioClip>();
    public List<AudioClip> pickUpSounds = new List<AudioClip>();
    public List<AudioClip> victorySounds = new List<AudioClip>();

    private void Awake()
    {
        current = this;
    }
    
    AudioClip randomFromList(List<AudioClip> list) {
        return list[Random.Range(0, list.Count)];
    }

    public void playRandomCannonExplosionSound() {
        AudioSource soundDummy = Instantiate(soundDummyPrefab).GetComponent<AudioSource>();
        soundDummy.clip = randomFromList(cannonExplosionSounds);
        Destroy(soundDummy.gameObject, soundDummy.clip.length + .5f);
        soundDummy.Play();
    }
    public void playRandomEnemyExplosionSound() {
        AudioSource soundDummy = Instantiate(soundDummyPrefab).GetComponent<AudioSource>();
        soundDummy.clip = randomFromList(enemyExplosionSounds);
        Destroy(soundDummy.gameObject, soundDummy.clip.length + .5f);
        soundDummy.Play();
    }
    public void playRandomWarningSound() {
        AudioSource soundDummy = Instantiate(soundDummyPrefab).GetComponent<AudioSource>();
        soundDummy.clip = randomFromList(warningSounds);
        Destroy(soundDummy.gameObject, soundDummy.clip.length + .5f);
        soundDummy.Play();
    }
    public void playRandomJumpSound() {
        AudioSource soundDummy = Instantiate(soundDummyPrefab).GetComponent<AudioSource>();
        soundDummy.clip = randomFromList(jumpSounds);
        Destroy(soundDummy.gameObject, soundDummy.clip.length + .5f);
        soundDummy.Play();
    }
    public void playRandomHurtSound() {
        AudioSource soundDummy = Instantiate(soundDummyPrefab).GetComponent<AudioSource>();
        soundDummy.clip = randomFromList(hurtSounds);
        Destroy(soundDummy.gameObject, soundDummy.clip.length + .5f);
        soundDummy.Play();
    }
    public void playRandomPickUpSound() {
        AudioSource soundDummy = Instantiate(soundDummyPrefab).GetComponent<AudioSource>();
        soundDummy.clip = randomFromList(pickUpSounds);
        Destroy(soundDummy.gameObject, soundDummy.clip.length + .5f);
        soundDummy.Play();
    }
    public void playRandomVictorySound() {
        AudioSource soundDummy = Instantiate(soundDummyPrefab).GetComponent<AudioSource>();
        soundDummy.clip = randomFromList(victorySounds);
        Destroy(soundDummy.gameObject, soundDummy.clip.length + .5f);
        soundDummy.Play();
    }
}
