using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float walkSpeed = 3;
    public float runSpeed = 5;
    float movementSpeed;
    public float timeToRun = .4f;
    float runThreshold;
    float lastFrameRunValue = 0;
    float lastGroundedMoveSpeed;

    public float groundCheckRadius = .25f;
    Transform groundCheck;

    public float jumpForce = 2;
    float jumpModifyer;
    Rigidbody2D rb;
    bool isJumping;
    public float jumpDuration = .35f;
    float jumpDurationThreshold;

    bool carryingObject;

    SpriteRenderer sr;
    Animator anim;

    float stunTime;

    private void Start()
    {
        groundCheck = transform.GetChild(0);
        rb = GetComponent<Rigidbody2D>();
        sr = transform.GetChild(1).GetComponent<SpriteRenderer>();
        anim = sr.GetComponent<Animator>();
    }

    void Update() {
        if (Time.time > stunTime) {
            HorizontalMovement();
            VerticalMovement();

            anim.SetBool("isCarrying", carryingObject);
            anim.SetBool("isFalling", !IsGrounded());
        } else {
            anim.SetBool("isFalling", true);
        }
    }

    void HorizontalMovement() {
        if (lastFrameRunValue == 0 && Input.GetAxisRaw("Horizontal") != 0) {
            runThreshold = Time.time + timeToRun;
        }

        anim.SetBool("isMoving", Input.GetAxisRaw("Horizontal") != 0);

        if (Input.GetAxisRaw("Horizontal") < 0) {
            sr.flipX = true;
        } else if (Input.GetAxisRaw("Horizontal") > 0) {
            sr.flipX = false;
        }

        if (IsGrounded()) {
            if (Time.time > runThreshold && !carryingObject) {
                movementSpeed = runSpeed;
                anim.SetBool("isRunning", true);
        }
            else {
                movementSpeed = walkSpeed;
                anim.SetBool("isRunning", false);
            }
        } else {
            movementSpeed = lastGroundedMoveSpeed;
        }

        rb.velocity = new Vector2(Input.GetAxis("Horizontal") * movementSpeed, rb.velocity.y);
        lastFrameRunValue = Input.GetAxisRaw("Horizontal");
        lastGroundedMoveSpeed = movementSpeed;
    }

    void VerticalMovement() {
        if (carryingObject) { jumpModifyer = .675f; }
        else { jumpModifyer = 1; }

        if (IsGrounded() && Input.GetKeyDown(KeyCode.Space)) {
            AudioBank.current.playRandomJumpSound();

            rb.velocity += Vector2.up * jumpForce * jumpModifyer;
            isJumping = true;
            jumpDurationThreshold = Time.time + jumpDuration;
        }

        if (Input.GetKey(KeyCode.Space) && isJumping ) {
            if (Time.time < jumpDurationThreshold) {
                rb.velocity += Vector2.up * jumpForce * jumpModifyer * Time.deltaTime * 25;
            } else {
                isJumping = false;
            }
        }

        if (Input.GetKeyUp(KeyCode.Space)) {
            isJumping = false;
        }

        rb.velocity = new Vector2(rb.velocity.x, Mathf.Clamp(rb.velocity.y, -Mathf.Infinity, 20f));
    }

    bool IsGrounded() { return Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, LayerMask.GetMask("Ground")) != null && rb.velocity.y <= .05f; }

    public void ChangingCarryingState(bool setTo) {
        if (carryingObject && setTo == false) {
            Destroy(transform.GetChild(3).gameObject);
        }
        if (!carryingObject || setTo == false) { carryingObject = setTo; }
    }

    public bool GetCarryingState() { return carryingObject; }

    public void Stun(float duration)
    {
        stunTime = Time.time + duration;
    }
}
