using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIHeartsDisplay : MonoBehaviour
{
    public List<SpriteRenderer> hearts = new List<SpriteRenderer>();
    public Sprite filled, empty;

    EnemyShipScript currentEnemy;

    void Start()
    {
        
    }

    void Update()
    {
        if (currentEnemy == null) {
            if (FindObjectOfType<EnemyShipScript>() != null) {
                currentEnemy = FindObjectOfType<EnemyShipScript>();
            }
        }

        if (currentEnemy != null) {
            foreach (SpriteRenderer heart in hearts) {
                heart.sprite = empty;
            }
            for (int i = 0; i < currentEnemy.GetHealth(); i++) {
                hearts[i].sprite = filled;
            }
        }
    }
}
