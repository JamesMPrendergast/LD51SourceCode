using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CameraController : MonoBehaviour
{
    Transform player;

    float leftClamp;
    float rightClamp;
    float topClamp;
    float bottomClamp;

    float tiltModifyer = 1;

    public bool playerLost = false;

    Vector2 offset = Vector2.zero;

    // Start is called before the first frame update
    void Start()
    {
        LineRenderer lr = GetComponent<LineRenderer>();
        lr.enabled = false;
        Camera cam = GetComponent<Camera>();
        float verticalDis = cam.orthographicSize;
        float horizontalDis = verticalDis * cam.aspect;

        leftClamp = lr.GetPosition(0).x + horizontalDis;
        rightClamp = lr.GetPosition(2).x - horizontalDis;
        topClamp = lr.GetPosition(1).y - verticalDis;
        bottomClamp = lr.GetPosition(3).y + verticalDis;

        player = FindObjectOfType<PlayerMovement>().transform;
    }

    void Update()
    {
        transform.position = player.transform.position;
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, leftClamp, rightClamp), Mathf.Clamp(transform.position.y, bottomClamp, topClamp), -10);
        transform.position = transform.position + (Vector3)offset;

        transform.rotation = Quaternion.Euler(Vector3.Lerp(Vector3.back * tiltModifyer, Vector3.forward * tiltModifyer, .5f * Mathf.Sin(Time.time) + .5f));
    }

    public IEnumerator Shake(float duration, float magnitude)
    {
        offset = Vector3.zero;
        float elapsed = 0;
        float lastInterval = 0;
        while (elapsed < duration) {
            float x = Random.Range(-1f, 1f) * magnitude;
            float y = Random.Range(-1f, 1f) * magnitude;
            offset = new Vector3(x, y);

            elapsed += Time.deltaTime;

            if (playerLost && Mathf.Floor(elapsed * 4) > lastInterval) {
                lastInterval = Mathf.Floor(elapsed * 4);
                ParticleBank.current.playEnemyExplosion(new Vector3(Random.Range(-20f, 10f), Random.Range(-7.5f, 7.5f), -3));
                AudioBank.current.playRandomEnemyExplosionSound();
            }

            yield return null;
        }
        if (playerLost) {
            SceneManager.LoadScene("End");
        }
        offset = Vector3.zero;
    }

    public void levelUpTilt()
    {
        tiltModifyer += .5f;
    }
}
