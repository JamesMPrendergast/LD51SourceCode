using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SemiSolid : MonoBehaviour
{
    float cooldown = .5f;
    float threshold;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.S) || Input.GetKey(KeyCode.S)) {
            threshold = Time.time + cooldown;
        }

        SetColliders(Time.time > threshold);
    }

    void SetColliders(bool setTo)
    {
        foreach(Collider2D collider in GetComponents<Collider2D>()) {
            collider.enabled = setTo;
        }
    }
}
