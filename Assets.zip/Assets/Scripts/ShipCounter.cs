using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShipCounter : MonoBehaviour
{
    Text t;

    void Start()
    {
        t = GetComponent<Text>();
        PlayerPrefs.SetInt("ShipsSunk", 0);
    }

    void Update()
    {
        t.text = PlayerPrefs.GetInt("ShipsSunk", 0).ToString();
    }
}
