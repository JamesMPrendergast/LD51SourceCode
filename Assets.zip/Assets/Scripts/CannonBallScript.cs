using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonBallScript : MonoBehaviour
{
    bool collected;
    static float offset = .25f;
    Vector2 topSpot;
    Vector2 bottomSpot;
    float startTime;

    void Start()
    {
        startTime = Time.time;
        topSpot = new Vector2(transform.position.x, transform.position.y + offset);
        bottomSpot = new Vector2(transform.position.x, transform.position.y - offset);
    }

    void Update()
    {
        if (!collected) {
            transform.position = Vector2.Lerp(bottomSpot, topSpot, .5f * Mathf.Sin(Time.time - startTime) + .5f);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player")) {
            if (!other.GetComponent<PlayerMovement>().GetCarryingState()) {
                AudioBank.current.playRandomPickUpSound();
                GetComponent<Collider2D>().enabled = false;
                other.GetComponent<PlayerMovement>().ChangingCarryingState(true);
                transform.parent = other.transform;
                transform.localPosition = Vector2.up * 2.375f;
                collected = true;
            }
        }
    }
}
